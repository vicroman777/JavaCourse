package vr222ed_assign1;

public class Fahrenheit {

	public static void ftoc(float fh) 
	{
		System.out.println("In celsius " + (((fh-32)*5)/9));
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
	ftoc(100);
	}

}
