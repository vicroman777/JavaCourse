package vr222ed_assign1;

import java.util.Scanner;

public class SumOfThree {
	static Scanner s = new Scanner(System.in);
	
	public static int sum(int a, int b, int c) 
	{
		return a + b + c;
		
	}

	public static void main(String[] args) {
		System.out.println("Give three numbers");
		int a = s.nextInt();
		int b = s.nextInt();
		int c = s.nextInt();	
		System.out.println("result " + sum(a, b, c));
	}
}
